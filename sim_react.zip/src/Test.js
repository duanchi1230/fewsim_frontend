import React, { Component } from 'react';

class Test extends Component {
    state = {  }
    render() { 
        return ( "This is just a test!" );
    }
}
 
export default Test;