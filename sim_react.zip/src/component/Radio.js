import React, { Component } from 'react';
import { Radio} from 'antd';
import "antd/dist/antd.css";

class DropList extends Component {

  render() {
    return (
      <Radio.Group onChange={this.props.onChange} value={this.props.value}>
        <Radio value={1}>Sort by Demand</Radio>
        <Radio value={2}>Sort by Scenario</Radio>
        <Radio value={3}>Sort by Supply</Radio>
      </Radio.Group>
    );
  }
}
 

export default DropList;