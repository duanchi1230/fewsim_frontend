// import React from 'react';
import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import PixMatrix from './component/PixelMapCanvas'


class App extends Component {
  state = {
    value: 1,
  };

  onChange = e => {
    // console.log('radio checked', e.target.value);
    this.setState({
      value: e.target.value,
    });
  };

  render() { 
    fetch("proj/1/weap/scenario/1").then(response=>response.json().then(data=> console.log(data)))
    return ( 
      <div>
      <div className="App">
        FEWSim
      </div>
      <h1><PixMatrix value={this.state.value} onChange={this.onChange}/></h1>
      </div>
     );
  }
}
 
export default App;


// function App() {

//   return ( 
//     <div>
//     <div className="App">
//       FEWSim
//     </div>
//     <h1><PixMatrix/></h1>
//     </div>
//   );
// }

// export default App;
